

1) Copy and Paste the files: ARDUINO.IDX and ARDUINO.LIB in...

C:\Program Files\Labcenter Electronics\Proteus 7 Professional\LIBRARY

or

C:\Program Files\Labcenter Electronics\Proteus 8 Professional\Data\LIBRARY


or another directory of the libraries of the Proteus.






1) Copie e cole os arquivos: ARDUINO.IDX e ARDUINO.LIB em...

C:\Arquivos de Programas\Labcenter Electronics\Proteus 7 Professional\LIBRARY

ou

C:\Program Files\Labcenter Electronics\Proteus 8 Professional\Data\LIBRARY


ou em outro diretorio de bibliotecas do Proteus.



